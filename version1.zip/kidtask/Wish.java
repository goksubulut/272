package kidtask;

import java.time.LocalDateTime;

public class Wish {
    private int id;
    private String title;
    private String description;
    private int points;
    private boolean isCompleted;
    private boolean isApproved;
    private char assignedBy; // 'T' for Teacher, 'P' for Parent
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private boolean isActivity;
    private int requiredLevel;

    public Wish(int id, String title, String description, int points, 
               boolean isCompleted, boolean isApproved, char assignedBy,
               boolean isActivity) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.points = points;
        this.isCompleted = isCompleted;
        this.isApproved = isApproved;
        this.assignedBy = assignedBy;
        this.isActivity = isActivity;
        this.requiredLevel = 1;
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public int getPoints() { return points; }
    public boolean isCompleted() { return isCompleted; }
    public boolean isApproved() { return isApproved; }
    public char getAssignedBy() { return assignedBy; }
    public LocalDateTime getStartTime() { return startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public boolean isActivity() { return isActivity; }
    public int getRequiredLevel() { return requiredLevel; }

    // Setters
    public void setCompleted(boolean completed) { isCompleted = completed; }
    public void setApproved(boolean approved) { isApproved = approved; }
    public void setRequiredLevel(int level) { this.requiredLevel = level; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    @Override
    public String toString() {
        String result = String.format("%d|%s|%s|%d|%b|%b|%c",
                id, title, description, points, isCompleted, isApproved, assignedBy);
        
        if (isActivity && startTime != null && endTime != null) {
            result += String.format("|%s|%s", startTime, endTime);
        }
        
        return result;
    }
} 