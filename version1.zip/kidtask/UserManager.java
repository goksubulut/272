package kidtask;

public class UserManager {
    int points = 0;

    public void addPoints(int p) {
        points += p;
    }

    public int getLevel(double avgRating) {
        if (avgRating >= 80) return 4;
        if (avgRating >= 60) return 3;
        if (avgRating >= 40) return 2;
        return 1;
    }

    public void printBudget() {
        System.out.println("Total Points: " + points);
    }

    public void printStatus(double avgRating) {
        System.out.println("Current Level: " + getLevel(avgRating));
    }
}

