package kidtask;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WishManager {
    private static final String WISHES_FILE = "C:\\Users\\ASUS\\OneDrive\\Desktop\\wishes.txt";
    private List<Wish> wishes;

    public WishManager() throws IOException {
        wishes = new ArrayList<>();
        loadWishes();
    }

    private void loadWishes() throws IOException {
        File file = new File(WISHES_FILE);
        if (!file.exists()) {
            file.createNewFile();
            System.out.println("İstek dosyası oluşturuldu: " + WISHES_FILE);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                Wish wish = parseWish(line);
                if (wish != null) {
                    wishes.add(wish);
                }
            }
        }
    }

    private Wish parseWish(String line) {
        try {
            String[] parts = line.split("\\|");
            int id = Integer.parseInt(parts[0]);
            String title = parts[1];
            String description = parts[2];
            int points = Integer.parseInt(parts[3]);
            boolean isCompleted = Boolean.parseBoolean(parts[4]);
            boolean isApproved = Boolean.parseBoolean(parts[5]);
            char assignedBy = parts[6].charAt(0);

            return new Wish(id, title, description, points, isCompleted, isApproved, assignedBy, isApproved);
        } catch (Exception e) {
            System.err.println("İstek ayrıştırma hatası: " + e.getMessage());
            return null;
        }
    }

    public void addWish(Wish wish) throws IOException {
        wishes.add(wish);
        saveWishes();
    }

    public void updateWish(Wish wish) throws IOException {
        for (int i = 0; i < wishes.size(); i++) {
            if (wishes.get(i).getId() == wish.getId()) {
                wishes.set(i, wish);
                saveWishes();
                return;
            }
        }
    }

    private void saveWishes() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(WISHES_FILE))) {
            for (Wish wish : wishes) {
                writer.write(wish.toString());
                writer.newLine();
            }
        }
    }

    public List<Wish> getAllWishes() {
        return new ArrayList<>(wishes);
    }

    public Wish getWishById(int id) {
        return wishes.stream()
                   .filter(wish -> wish.getId() == id)
                   .findFirst()
                   .orElse(null);
    }

    public void deleteWish(int id) throws IOException {
        wishes.removeIf(wish -> wish.getId() == id);
        saveWishes();
    }
}
