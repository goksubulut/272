package kidtask;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Task {
    private int id;
    private String title;
    private String description;
    private String deadline;
    private String startTime;
    private String endTime;
    private int points;
    private boolean isCompleted;
    private boolean isApproved;
    private double rating;
    private char assignedBy; // 'T' for Teacher, 'P' for Parent

    public Task(int id, String title, String description, String deadline, String startTime, 
               String endTime, int points, boolean isCompleted, boolean isApproved, 
               double rating, char assignedBy) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.startTime = startTime;
        this.endTime = endTime;
        this.points = points;
        this.isCompleted = isCompleted;
        this.isApproved = isApproved;
        this.rating = rating;
        this.assignedBy = assignedBy;
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getDeadline() { return deadline; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public int getPoints() { return points; }
    public boolean isCompleted() { return isCompleted; }
    public boolean isApproved() { return isApproved; }
    public double getRating() { return rating; }
    public char getAssignedBy() { return assignedBy; }

    // Setters
    public void setCompleted(boolean completed) { isCompleted = completed; }
    public void setApproved(boolean approved) { isApproved = approved; }
    public void setRating(double rating) { this.rating = rating; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    @Override
    public String toString() {
        return String.format("%d|%s|%s|%s|%s|%s|%d|%b|%b|%.2f|%c",
                id, title, description, deadline, startTime, endTime,
                points, isCompleted, isApproved, rating, assignedBy);
    }
} 