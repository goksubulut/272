package kidtask;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private static final String TASKS_FILE = "C:\\Users\\ASUS\\OneDrive\\Desktop\\tasks.txt";
    private List<Task> tasks;

    public TaskManager() throws IOException {
        tasks = new ArrayList<>();
        loadTasks();
    }

    private void loadTasks() throws IOException {
        File file = new File(TASKS_FILE);
        if (!file.exists()) {
            file.createNewFile();
            System.out.println("Görev dosyası oluşturuldu: " + TASKS_FILE);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                Task task = parseTask(line);
                if (task != null) {
                    tasks.add(task);
                }
            }
        }
    }

    private Task parseTask(String line) {
        try {
            String[] parts = line.split("\\|");
            int id = Integer.parseInt(parts[0]);
            String title = parts[1];
            String description = parts[2];
            String deadline = parts[3];
            String startTime = parts[4];
            String endTime = parts[5];
            int points = Integer.parseInt(parts[6]);
            boolean isCompleted = Boolean.parseBoolean(parts[7]);
            boolean isApproved = Boolean.parseBoolean(parts[8]);
            double rating = Double.parseDouble(parts[9]);
            char assignedBy = parts[10].charAt(0);

            return new Task(id, title, description, deadline, startTime, endTime, 
                          points, isCompleted, isApproved, rating, assignedBy);
        } catch (Exception e) {
            System.err.println("Görev ayrıştırma hatası: " + e.getMessage());
            return null;
        }
    }

    public void addTask(Task task) throws IOException {
        tasks.add(task);
        saveTasks();
    }

    public void updateTask(Task task) throws IOException {
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getId() == task.getId()) {
                tasks.set(i, task);
                saveTasks();
                return;
            }
        }
    }

    private void saveTasks() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TASKS_FILE))) {
            for (Task task : tasks) {
                writer.write(task.toString());
                writer.newLine();
            }
        }
    }

    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    public Task getTaskById(int id) {
        return tasks.stream()
                   .filter(task -> task.getId() == id)
                   .findFirst()
                   .orElse(null);
    }

    public void deleteTask(int id) throws IOException {
        tasks.removeIf(task -> task.getId() == id);
        saveTasks();
    }
}
