package kidtask;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ChildManager {
    private static final String CHILDREN_FILE = "C:\\Users\\ASUS\\OneDrive\\Desktop\\children.txt";
    private List<Child> children;

    public ChildManager() throws IOException {
        children = new ArrayList<>();
        loadChildren();
    }

    private void loadChildren() throws IOException {
        File file = new File(CHILDREN_FILE);
        if (!file.exists()) {
            file.createNewFile();
            System.out.println("Çocuklar dosyası oluşturuldu: " + CHILDREN_FILE);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                Child child = parseChild(line);
                if (child != null) {
                    children.add(child);
                }
            }
        }
    }

    private Child parseChild(String line) {
        try {
            String[] parts = line.split("\\|");
            int id = Integer.parseInt(parts[0]);
            String name = parts[1];
            int points = Integer.parseInt(parts[2]);
            int level = Integer.parseInt(parts[3]);
            double averageRating = Double.parseDouble(parts[4]);

            Child child = new Child(id, name);
            child.addPoints(points);
            child.updateRating(averageRating);
            return child;
        } catch (Exception e) {
            System.err.println("Çocuk ayrıştırma hatası: " + e.getMessage());
            return null;
        }
    }

    public void addChild(Child child) throws IOException {
        children.add(child);
        saveChildren();
    }

    public void updateChild(Child child) throws IOException {
        for (int i = 0; i < children.size(); i++) {
            if (children.get(i).getId() == child.getId()) {
                children.set(i, child);
                saveChildren();
                return;
            }
        }
    }

    private void saveChildren() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CHILDREN_FILE))) {
            for (Child child : children) {
                writer.write(child.toString());
                writer.newLine();
            }
        }
    }

    public List<Child> getAllChildren() {
        return new ArrayList<>(children);
    }

    public Child getChildById(int id) {
        return children.stream()
                      .filter(child -> child.getId() == id)
                      .findFirst()
                      .orElse(null);
    }

    public void deleteChild(int id) throws IOException {
        children.removeIf(child -> child.getId() == id);
        saveChildren();
    }
} 