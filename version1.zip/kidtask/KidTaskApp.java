package kidtask;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.List;
import java.util.stream.Collectors;

public class KidTaskApp {
    private static final String COMMANDS_FILE = "C:\\Users\\ASUS\\OneDrive\\Desktop\\Commands.txt";
    private TaskManager taskManager;
    private WishManager wishManager;
    private ChildManager childManager;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public KidTaskApp() throws IOException {
        taskManager = new TaskManager();
        wishManager = new WishManager();
        childManager = new ChildManager();
    }

    public void start() {
        try (Scanner scanner = new Scanner(new File(COMMANDS_FILE))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                
                String[] parts = line.split("\\s+");
                if (parts.length < 2) continue;

                String command = parts[0];
                String[] params = new String[parts.length - 1];
                System.arraycopy(parts, 1, params, 0, params.length);

                processCommand(command, params);
            }
        } catch (IOException e) {
            System.err.println("Komut dosyası okuma hatası: " + e.getMessage());
        }
    }

    private void processCommand(String command, String[] params) {
        try {
            switch (command) {
                case "ADD_TASK1":
                    processAddTask1(params);
                    break;
                case "ADD_TASK2":
                    processAddTask2(params);
                    break;
                case "ADD_WISH1":
                    processAddWish1(params);
                    break;
                case "ADD_WISH2":
                    processAddWish2(params);
                    break;
                case "TASK_DONE":
                    processTaskDone(params);
                    break;
                case "TASK_CHECKED":
                    processTaskChecked(params);
                    break;
                case "WISH_CHECKED":
                    processWishChecked(params);
                    break;
                case "PRINT_BUDGET":
                    processPrintBudget();
                    break;
                case "PRINT_STATUS":
                    processPrintStatus();
                    break;
                case "LIST_ALL_TASKS":
                    listAllTasks();
                    break;
                case "LIST_ALL_WISHES":
                    listAllWishes();
                    break;
                default:
                    System.err.println("Bilinmeyen komut: " + command);
            }
        } catch (Exception e) {
            System.err.println("Komut işleme hatası: " + e.getMessage());
        }
    }

    private void processAddTask1(String[] params) throws IOException {
        if (params.length < 6) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        char assignedBy = params[0].charAt(0);
        int id = Integer.parseInt(params[1]);
        String title = params[2].replace("\"", "");
        String description = params[3].replace("\"", "");
        String deadlineDate = params[4];
        String deadlineTime = params[5];
        int points = Integer.parseInt(params[6]);

        String deadline = deadlineDate + " " + deadlineTime;
        Task task = new Task(id, title, description, deadline, null, null, 
                           points, false, false, 0.0, assignedBy);
        taskManager.addTask(task);
        System.out.println("Görev eklendi: " + title);
    }

    private void processAddTask2(String[] params) throws IOException {
        if (params.length < 9) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        char assignedBy = params[0].charAt(0);
        int id = Integer.parseInt(params[1]);
        String title = params[2].replace("\"", "");
        String description = params[3].replace("\"", "");
        String deadlineDate = params[4];
        String deadlineTime = params[5];
        String startDate = params[6];
        String startTime = params[7];
        String endDate = params[8];
        String endTime = params[9];
        int points = Integer.parseInt(params[10]);

        String deadline = deadlineDate + " " + deadlineTime;
        String start = startDate + " " + startTime;
        String end = endDate + " " + endTime;

        Task task = new Task(id, title, description, deadline, start, end, 
                           points, false, false, 0.0, assignedBy);
        taskManager.addTask(task);
        System.out.println("Görev eklendi: " + title);
    }

    private void processAddWish1(String[] params) throws IOException {
        if (params.length < 3) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        String id = params[0];
        String title = params[1].replace("\"", "");
        String description = params[2].replace("\"", "");

        Wish wish = new Wish(Integer.parseInt(id.substring(1)), title, description, 0, false, false, 'P', false);
        wishManager.addWish(wish);
        System.out.println("İstek eklendi: " + title);
    }

    private void processAddWish2(String[] params) throws IOException {
        if (params.length < 6) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        String id = params[0];
        String title = params[1].replace("\"", "");
        String description = params[2].replace("\"", "");
        String startDate = params[3];
        String startTime = params[4];
        String endDate = params[5];
        String endTime = params[6];

        Wish wish = new Wish(Integer.parseInt(id.substring(1)), title, description, 0, false, false, 'P', false);
        wishManager.addWish(wish);
        System.out.println("İstek eklendi: " + title);
    }

    private void processTaskDone(String[] params) throws IOException {
        if (params.length < 1) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        int taskId = Integer.parseInt(params[0]);
        Task task = taskManager.getTaskById(taskId);
        if (task != null) {
            task.setCompleted(true);
            taskManager.updateTask(task);
            System.out.println("Görev tamamlandı: " + task.getTitle());
        }
    }

    private void processTaskChecked(String[] params) throws IOException {
        if (params.length < 2) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        int taskId = Integer.parseInt(params[0]);
        int rating = Integer.parseInt(params[1]);
        Task task = taskManager.getTaskById(taskId);
        if (task != null) {
            task.setApproved(true);
            task.setRating(rating);
            taskManager.updateTask(task);
            System.out.println("Görev kontrol edildi: " + task.getTitle() + ", Puan: " + rating);
        }
    }

    private void processWishChecked(String[] params) throws IOException {
        if (params.length < 3) {
            System.err.println("Yetersiz parametre sayısı");
            return;
        }

        String wishId = params[0];
        boolean approved = params[1].equals("APPROVED");
        int requiredLevel = Integer.parseInt(params[2]);
        Wish wish = wishManager.getWishById(Integer.parseInt(wishId.substring(1)));
        if (wish != null) {
            wish.setApproved(approved);
            wishManager.updateWish(wish);
            System.out.println("İstek kontrol edildi: " + wish.getTitle() + ", Onay: " + approved);
        }
    }

    private void processPrintBudget() {
        Child child = childManager.getChildById(1);
        if (child != null) {
            System.out.println("Mevcut Bütçe: " + child.getPoints() + " puan");
        }
    }

    private void processPrintStatus() {
        Child child = childManager.getChildById(1);
        if (child != null) {
            System.out.println(child);
        }
    }

    private void listAllTasks() {
        System.out.println("\nTüm Görevler:");
        for (Task task : taskManager.getAllTasks()) {
            System.out.println(task);
        }
    }

    private void listAllWishes() {
        System.out.println("\nTüm İstekler:");
        for (Wish wish : wishManager.getAllWishes()) {
            System.out.println(wish);
        }
    }

    public static void main(String[] args) {
        try {
            KidTaskApp app = new KidTaskApp();
            app.start();
        } catch (IOException e) {
            System.err.println("Uygulama başlatma hatası: " + e.getMessage());
        }
    }
} 