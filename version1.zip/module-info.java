/**
 * 
 */
/**
 * 
 */
module KidTask {
}